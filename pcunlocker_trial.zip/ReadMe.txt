Dear Valued Customer,

Thanks for choosing the PCUnlocker utility!

This trial version is for evaluation purpose only. 
For registered user, please download the full version via the download link included in your order confirmation email.

How to reset forgotten Windows local admin/user password:
http://www.top-password.com/guide/reset-windows-password.html

How to reset forgotten Windows domain admin/user password:
http://www.top-password.com/guide/reset-windows-domain-password.html

////////////////////////////////FAQ////////////////////////////////////

How to set your computer to boot from CD or USB drive?
http://www.top-password.com/blog/how-to-set-your-computer-to-boot-from-cd-or-usb-drive/

What to do if PCUnlocker can't find Windows SAM or NTDS.dit file? 
http://www.top-password.com/knowledge/load-hard-disk-drivers.html

Can't boot from PCUnlocker Live CD/USB drive?
http://www.top-password.com/knowledge/cant-boot-from-windows-password-reset-disk.html

Note: For computers with Windows 8/10 pre-installed, in order to boot from PCUnlocker Live CD/USB drive
you also need to disable UEFI mode and turn off Secure Boot option in BIOS:
http://www.top-password.com/blog/set-windows-8-pc-to-boot-with-legacy-bios-mode-instead-of-uefi-mode/

If you have any questions, please do not hesitate to contact our support team at any time if you need assistance.

Regards,

Top Password Software, Inc.
support@top-password.com